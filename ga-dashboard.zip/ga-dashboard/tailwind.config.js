/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,jsx}", "./components/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        bg: "#15171C",
        panel: "#1B1E25",
        line: "#2A2D36",
        muted: "#8A8D96",
        accent1: "#E8A33D",
        accent2: "#3DA5A8",
      },
    },
  },
  plugins: [],
};
