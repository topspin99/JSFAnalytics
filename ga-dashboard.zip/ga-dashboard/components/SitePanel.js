"use client";

function formatDuration(seconds) {
  const m = Math.floor(seconds / 60);
  const s = Math.round(seconds % 60);
  return `${m}m ${s}s`;
}

function pct(part, whole) {
  if (!whole) return null;
  return Math.round((part / whole) * 100);
}

function StatRow({ label, value, sharePct, accentClass }) {
  return (
    <div className="flex items-baseline justify-between border-b border-line py-3">
      <span className="text-sm text-muted">{label}</span>
      <span className="flex items-baseline gap-2">
        <span className={`mono text-xl font-medium ${accentClass}`}>{value}</span>
        {sharePct !== null && sharePct !== undefined && (
          <span className="mono text-xs text-muted">({sharePct}%)</span>
        )}
      </span>
    </div>
  );
}

function MiniList({ title, items, valueKey, labelKey }) {
  if (!items || items.length === 0) {
    return (
      <div className="pt-4">
        <div className="text-xs uppercase tracking-wide text-muted mb-2">{title}</div>
        <div className="text-sm text-muted">No data for this range.</div>
      </div>
    );
  }
  const max = Math.max(...items.map((i) => i[valueKey]));
  const total = items.reduce((sum, i) => sum + i[valueKey], 0);
  return (
    <div className="pt-4">
      <div className="text-xs uppercase tracking-wide text-muted mb-2">{title}</div>
      <div className="space-y-1.5">
        {items.map((item, i) => (
          <div key={i} className="flex items-center gap-2">
            <span className="text-xs text-text/80 w-28 truncate" title={item[labelKey]}>
              {item[labelKey]}
            </span>
            <div className="flex-1 h-1.5 bg-line rounded-full overflow-hidden">
              <div
                className="h-full bg-current opacity-60"
                style={{ width: `${(item[valueKey] / max) * 100}%` }}
              />
            </div>
            <span className="mono text-xs text-muted w-10 text-right">{item[valueKey]}</span>
            <span className="mono text-xs text-muted w-10 text-right">
              {pct(item[valueKey], total)}%
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function SitePanel({ propertyId, accent, data, otherTotals, loading, error }) {
  const accentColor = accent === 1 ? "#E8A33D" : "#3DA5A8";
  const accentClass = accent === 1 ? "text-accent1" : "text-accent2";
  const accentBg = accent === 1 ? "bg-accent1" : "bg-accent2";

  const t = data?.totals;
  const o = otherTotals;

  return (
    <div className="relative flex bg-panel rounded-lg overflow-hidden border border-line">
      {/* Signature spine: accent-colored edge with property id label */}
      <div
        className={`w-6 flex items-center justify-center shrink-0 ${accentBg}`}
        aria-hidden="true"
      >
        <span
          className="mono text-[10px] text-bg/80 tracking-widest"
          style={{ writingMode: "vertical-rl", transform: "rotate(180deg)" }}
        >
          {propertyId}
        </span>
      </div>

      <div className="flex-1 p-5">
        <h2 className="text-lg font-semibold mb-4" style={{ color: accentColor }}>
          {loading ? "Loading…" : data?.label || propertyId}
        </h2>

        {error && (
          <div className="text-sm text-red-400 border border-red-900/40 bg-red-950/30 rounded p-3">
            {error}
          </div>
        )}

        {loading && (
          <div className="space-y-3 animate-pulse" style={{ animationDuration: "1.5s" }}>
            {[0, 1, 2, 3, 4].map((i) => (
              <div key={i} className="h-6 bg-line rounded" />
            ))}
          </div>
        )}

        {data && !loading && !error && (
          <>
            <StatRow
              label="Active users"
              value={t.activeUsers.toLocaleString()}
              sharePct={o ? pct(t.activeUsers, t.activeUsers + o.activeUsers) : null}
              accentClass={accentClass}
            />
            <StatRow
              label="Sessions"
              value={t.sessions.toLocaleString()}
              sharePct={o ? pct(t.sessions, t.sessions + o.sessions) : null}
              accentClass={accentClass}
            />
            <StatRow
              label="Page views"
              value={t.pageViews.toLocaleString()}
              sharePct={o ? pct(t.pageViews, t.pageViews + o.pageViews) : null}
              accentClass={accentClass}
            />
            <StatRow
              label="Bounce rate"
              value={`${(t.bounceRate * 100).toFixed(1)}%`}
              accentClass={accentClass}
            />
            <StatRow
              label="Avg. session"
              value={formatDuration(t.avgSessionDuration)}
              accentClass={accentClass}
            />

            <div className={accentClass}>
              <MiniList title="Top channels" items={data.sources} valueKey="sessions" labelKey="name" />
              <MiniList title="Top pages" items={data.topPages} valueKey="views" labelKey="path" />
              <MiniList title="Devices" items={data.devices} valueKey="sessions" labelKey="name" />
            </div>
          </>
        )}
      </div>
    </div>
  );
}
