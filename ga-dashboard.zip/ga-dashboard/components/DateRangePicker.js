"use client";

import { useState, useRef, useEffect } from "react";
import {
  format,
  startOfMonth,
  endOfMonth,
  startOfWeek,
  endOfWeek,
  addDays,
  addMonths,
  subMonths,
  isSameDay,
  isWithinInterval,
  isAfter,
  isBefore,
  parseISO,
} from "date-fns";

const PRESETS = [
  { label: "7 days", startDate: "7daysAgo", endDate: "today" },
  { label: "30 days", startDate: "30daysAgo", endDate: "today" },
  { label: "90 days", startDate: "90daysAgo", endDate: "today" },
];

// GA accepts relative strings like "7daysAgo" OR literal YYYY-MM-DD dates.
// This component emits literal dates once the user picks a custom range.
function toGaDate(date) {
  return format(date, "yyyy-MM-dd");
}

function buildMonthGrid(monthDate) {
  const start = startOfWeek(startOfMonth(monthDate));
  const end = endOfWeek(endOfMonth(monthDate));
  const days = [];
  let cur = start;
  while (cur <= end) {
    days.push(cur);
    cur = addDays(cur, 1);
  }
  return days;
}

function MonthGrid({ monthDate, rangeStart, rangeEnd, hoverDate, onPick, onHover }) {
  const days = buildMonthGrid(monthDate);
  const today = new Date();

  return (
    <div className="w-64">
      <div className="text-sm font-medium text-center mb-2">
        {format(monthDate, "MMMM yyyy")}
      </div>
      <div className="grid grid-cols-7 text-[11px] text-muted mb-1">
        {["S", "M", "T", "W", "T", "F", "S"].map((d, i) => (
          <div key={i} className="text-center py-1">{d}</div>
        ))}
      </div>
      <div className="grid grid-cols-7 gap-y-0.5">
        {days.map((day) => {
          const inMonth = day.getMonth() === monthDate.getMonth();
          const isFuture = isAfter(day, today);
          const effectiveEnd = rangeEnd || hoverDate;
          const inRange =
            rangeStart &&
            effectiveEnd &&
            !isAfter(rangeStart, effectiveEnd) &&
            isWithinInterval(day, {
              start: rangeStart,
              end: effectiveEnd,
            });
          const isStart = rangeStart && isSameDay(day, rangeStart);
          const isEnd = rangeEnd && isSameDay(day, rangeEnd);

          return (
            <button
              key={day.toISOString()}
              disabled={isFuture}
              onClick={() => onPick(day)}
              onMouseEnter={() => onHover(day)}
              className={[
                "text-xs h-8 w-8 rounded-md mx-auto flex items-center justify-center transition-colors",
                !inMonth ? "text-muted/40" : "text-text",
                isFuture ? "opacity-30 cursor-not-allowed" : "cursor-pointer hover:bg-line",
                inRange && !isStart && !isEnd ? "bg-line/70" : "",
                isStart || isEnd ? "bg-accent1 text-bg font-medium" : "",
              ].join(" ")}
            >
              {format(day, "d")}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export default function DateRangePicker({ value, onChange }) {
  const [open, setOpen] = useState(false);
  const [visibleMonth, setVisibleMonth] = useState(startOfMonth(new Date()));
  const [draftStart, setDraftStart] = useState(null);
  const [draftEnd, setDraftEnd] = useState(null);
  const [hoverDate, setHoverDate] = useState(null);
  const containerRef = useRef(null);

  useEffect(() => {
    function handleClickOutside(e) {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  function handlePick(day) {
    if (!draftStart || (draftStart && draftEnd)) {
      // starting a new selection
      setDraftStart(day);
      setDraftEnd(null);
    } else if (isBefore(day, draftStart)) {
      // picked an earlier date second — swap so start is always earliest
      setDraftEnd(draftStart);
      setDraftStart(day);
    } else {
      setDraftEnd(day);
    }
  }

  function applyCustomRange() {
    if (!draftStart || !draftEnd) return;
    onChange({
      label: `${format(draftStart, "MMM d")} – ${format(draftEnd, "MMM d")}`,
      startDate: toGaDate(draftStart),
      endDate: toGaDate(draftEnd),
    });
    setOpen(false);
  }

  function pickPreset(preset) {
    onChange(preset);
    setDraftStart(null);
    setDraftEnd(null);
    setOpen(false);
  }

  return (
    <div className="relative" ref={containerRef}>
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex items-center gap-2 bg-panel border border-line rounded-md px-3 py-2 text-sm hover:border-muted transition-colors"
      >
        <span>{value.label}</span>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-muted">
          <rect x="3" y="4" width="18" height="18" rx="2" />
          <path d="M16 2v4M8 2v4M3 10h18" />
        </svg>
      </button>

      {open && (
        <div className="absolute right-0 mt-2 z-20 bg-panel border border-line rounded-lg shadow-xl p-4 flex flex-col gap-4">
          <div className="flex gap-1">
            {PRESETS.map((preset) => (
              <button
                key={preset.label}
                onClick={() => pickPreset(preset)}
                className="px-3 py-1.5 text-xs rounded text-muted hover:text-text hover:bg-line transition-colors"
              >
                {preset.label}
              </button>
            ))}
          </div>

          <div className="flex items-center justify-between">
            <button
              onClick={() => setVisibleMonth((m) => subMonths(m, 1))}
              className="text-muted hover:text-text px-2"
              aria-label="Previous month"
            >
              ‹
            </button>
            <span className="text-xs text-muted">
              {draftStart && !draftEnd
                ? "Pick an end date"
                : draftStart && draftEnd
                ? `${format(draftStart, "MMM d, yyyy")} – ${format(draftEnd, "MMM d, yyyy")}`
                : "Pick a start date"}
            </span>
            <button
              onClick={() => setVisibleMonth((m) => addMonths(m, 1))}
              className="text-muted hover:text-text px-2"
              aria-label="Next month"
            >
              ›
            </button>
          </div>

          <div className="flex gap-4" onMouseLeave={() => setHoverDate(null)}>
            <MonthGrid
              monthDate={visibleMonth}
              rangeStart={draftStart}
              rangeEnd={draftEnd}
              hoverDate={hoverDate}
              onPick={handlePick}
              onHover={setHoverDate}
            />
            <MonthGrid
              monthDate={addMonths(visibleMonth, 1)}
              rangeStart={draftStart}
              rangeEnd={draftEnd}
              hoverDate={hoverDate}
              onPick={handlePick}
              onHover={setHoverDate}
            />
          </div>

          <div className="flex justify-end gap-2 pt-1 border-t border-line">
            <button
              onClick={() => setOpen(false)}
              className="text-xs px-3 py-1.5 text-muted hover:text-text transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={applyCustomRange}
              disabled={!draftStart || !draftEnd}
              className="text-xs px-3 py-1.5 rounded bg-accent1 text-bg font-medium disabled:opacity-30 disabled:cursor-not-allowed"
            >
              Apply
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export { PRESETS };
