import "./globals.css";
import Providers from "./providers";

export const metadata = {
  title: "Site Dashboard",
  description: "Analytics across your sites, side by side.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
