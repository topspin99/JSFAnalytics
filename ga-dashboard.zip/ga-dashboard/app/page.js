"use client";

import { useSession, signIn, signOut } from "next-auth/react";
import { useEffect, useState, useCallback } from "react";
import SitePanel from "../components/SitePanel";
import DateRangePicker, { PRESETS } from "../components/DateRangePicker";

const PROPERTY_IDS = [
  { id: process.env.NEXT_PUBLIC_GA_PROPERTY_ID_1 || "383895604", accent: 1 },
  { id: process.env.NEXT_PUBLIC_GA_PROPERTY_ID_2 || "504003265", accent: 2 },
];

export default function Home() {
  const { data: session, status } = useSession();
  const [range, setRange] = useState(PRESETS[1]); // default: 30 days
  const [results, setResults] = useState({});
  const [loadingIds, setLoadingIds] = useState([]);

  const fetchSite = useCallback(
    async (propertyId) => {
      setLoadingIds((prev) => [...prev, propertyId]);
      try {
        const res = await fetch(
          `/api/analytics/${propertyId}?startDate=${range.startDate}&endDate=${range.endDate}`
        );
        const json = await res.json();
        if (!res.ok) throw new Error(json.error || "Failed to load");
        setResults((prev) => ({ ...prev, [propertyId]: { data: json, error: null } }));
      } catch (err) {
        setResults((prev) => ({
          ...prev,
          [propertyId]: { data: null, error: err.message },
        }));
      } finally {
        setLoadingIds((prev) => prev.filter((id) => id !== propertyId));
      }
    },
    [range]
  );

  useEffect(() => {
    if (status === "authenticated") {
      PROPERTY_IDS.forEach((p) => fetchSite(p.id));
    }
  }, [status, range, fetchSite]);

  if (status === "loading") {
    return (
      <main className="min-h-screen flex items-center justify-center text-muted">
        Checking session…
      </main>
    );
  }

  if (status !== "authenticated") {
    return (
      <main className="min-h-screen flex flex-col items-center justify-center gap-6 px-6">
        <div className="text-center">
          <h1 className="text-2xl font-semibold mb-2">Site Dashboard</h1>
          <p className="text-muted text-sm max-w-sm">
            Sign in with the Google account that has access to your Analytics
            properties.
          </p>
        </div>
        <button
          onClick={() => signIn("google")}
          className="bg-accent1 text-bg font-medium px-5 py-2.5 rounded-md hover:opacity-90 transition-opacity"
        >
          Sign in with Google
        </button>
      </main>
    );
  }

  return (
    <main className="min-h-screen px-4 py-6 md:px-8 md:py-10 max-w-5xl mx-auto">
      <header className="flex flex-wrap items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-xl font-semibold">Site Dashboard</h1>
          <p className="text-sm text-muted">{session.user?.email}</p>
        </div>
        <div className="flex items-center gap-3">
          <DateRangePicker value={range} onChange={setRange} />
          <button
            onClick={() => signOut()}
            className="text-sm text-muted hover:text-text transition-colors"
          >
            Sign out
          </button>
        </div>
      </header>

      <div className="grid md:grid-cols-2 gap-5">
        {PROPERTY_IDS.map((p, i) => {
          const otherProperty = PROPERTY_IDS[i === 0 ? 1 : 0];
          return (
            <SitePanel
              key={p.id}
              propertyId={p.id}
              accent={p.accent}
              data={results[p.id]?.data}
              otherTotals={results[otherProperty.id]?.data?.totals}
              error={results[p.id]?.error}
              loading={loadingIds.includes(p.id)}
            />
          );
        })}
      </div>
    </main>
  );
}
