import { getServerSession } from "next-auth";
import { BetaAnalyticsDataClient } from "@google-analytics/data";

// Maps property IDs to friendly labels — extend this if you add more sites later
const PROPERTY_LABELS = {
  [process.env.GA_PROPERTY_ID_1]: process.env.GA_PROPERTY_LABEL_1 || "Site One",
  [process.env.GA_PROPERTY_ID_2]: process.env.GA_PROPERTY_LABEL_2 || "Site Two",
};

export async function GET(request, { params }) {
  const session = await getServerSession();

  if (!session?.accessToken) {
    return Response.json({ error: "Not signed in" }, { status: 401 });
  }

  const { propertyId } = params;
  const { searchParams } = new URL(request.url);
  const startDate = searchParams.get("startDate") || "30daysAgo";
  const endDate = searchParams.get("endDate") || "today";

  try {
    const analyticsDataClient = new BetaAnalyticsDataClient({
      authClient: {
        // Reuse the user's own OAuth access token instead of a service account
        getAccessToken: async () => ({ token: session.accessToken }),
        getRequestHeaders: async () => ({
          Authorization: `Bearer ${session.accessToken}`,
        }),
      },
    });

    const [report] = await analyticsDataClient.runReport({
      property: `properties/${propertyId}`,
      dateRanges: [{ startDate, endDate }],
      metrics: [
        { name: "activeUsers" },
        { name: "sessions" },
        { name: "bounceRate" },
        { name: "averageSessionDuration" },
        { name: "screenPageViews" },
      ],
    });

    const [sourceReport] = await analyticsDataClient.runReport({
      property: `properties/${propertyId}`,
      dateRanges: [{ startDate, endDate }],
      dimensions: [{ name: "sessionDefaultChannelGroup" }],
      metrics: [{ name: "sessions" }],
      limit: 5,
      orderBys: [{ metric: { metricName: "sessions" }, desc: true }],
    });

    const [pageReport] = await analyticsDataClient.runReport({
      property: `properties/${propertyId}`,
      dateRanges: [{ startDate, endDate }],
      dimensions: [{ name: "pagePath" }],
      metrics: [{ name: "screenPageViews" }],
      limit: 5,
      orderBys: [{ metric: { metricName: "screenPageViews" }, desc: true }],
    });

    const [deviceReport] = await analyticsDataClient.runReport({
      property: `properties/${propertyId}`,
      dateRanges: [{ startDate, endDate }],
      dimensions: [{ name: "deviceCategory" }],
      metrics: [{ name: "sessions" }],
      orderBys: [{ metric: { metricName: "sessions" }, desc: true }],
    });

    const row = report.rows?.[0]?.metricValues || [];

    return Response.json({
      propertyId,
      label: PROPERTY_LABELS[propertyId] || propertyId,
      totals: {
        activeUsers: Number(row[0]?.value || 0),
        sessions: Number(row[1]?.value || 0),
        bounceRate: Number(row[2]?.value || 0),
        avgSessionDuration: Number(row[3]?.value || 0),
        pageViews: Number(row[4]?.value || 0),
      },
      sources: (sourceReport.rows || []).map((r) => ({
        name: r.dimensionValues[0].value,
        sessions: Number(r.metricValues[0].value),
      })),
      topPages: (pageReport.rows || []).map((r) => ({
        path: r.dimensionValues[0].value,
        views: Number(r.metricValues[0].value),
      })),
      devices: (deviceReport.rows || []).map((r) => ({
        name: r.dimensionValues[0].value,
        sessions: Number(r.metricValues[0].value),
      })),
    });
  } catch (err) {
    console.error("GA fetch error:", err);
    return Response.json(
      { error: err.message || "Failed to fetch analytics data" },
      { status: 500 }
    );
  }
}
